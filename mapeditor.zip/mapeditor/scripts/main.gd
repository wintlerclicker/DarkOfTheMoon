extends Node2D

@onready var map_generator: MapGenerator = $MapGenerator
@onready var camera: Camera2D = $Camera2D
@onready var seed_edit: LineEdit = $UI/Panel/VBox/SeedRow/SeedEdit
@onready var width_edit: SpinBox = $UI/Panel/VBox/SizeRow/Width
@onready var height_edit: SpinBox = $UI/Panel/VBox/SizeRow/Height
@onready var status_label: Label = $UI/Panel/VBox/Status
@onready var biome_label: Label = $UI/Biome
@onready var player_preview: Sprite2D = $PlayerPreview
@onready var interior_panel: Panel = $UI/InteriorPanel

func _ready() -> void:
	seed_edit.text = str(map_generator.world_seed)
	width_edit.value = map_generator.world_width
	height_edit.value = map_generator.world_height
	map_generator.generation_started.connect(_on_generation_started)
	map_generator.generation_done.connect(_on_generation_done)
	map_generator.generation_error.connect(_on_generation_error)
	map_generator.generate()
	_update_player_preview()
	_focus_map()

func _update_player_preview() -> void:
	if is_instance_valid(player_preview):
		player_preview.position = Vector2(
			map_generator.world_width * map_generator.tile_size * 0.5,
			map_generator.world_height * map_generator.tile_size * 0.5
		)

func _on_interior_pressed() -> void:
	interior_panel.visible = not interior_panel.visible

func _process(_delta: float) -> void:
	var mouse_world := get_global_mouse_position()
	var b := map_generator.get_biome_at_world(mouse_world)
	biome_label.text = "Клетка: %d, %d   |   Биом: %s" % [int(mouse_world.x / map_generator.tile_size), int(mouse_world.y / map_generator.tile_size), map_generator.biome_name(b)]

func _on_generate_pressed() -> void:
	map_generator.world_width = int(width_edit.value)
	map_generator.world_height = int(height_edit.value)
	var parsed := seed_edit.text.strip_edges()
	if parsed.is_valid_int():
		map_generator.world_seed = int(parsed)
	else:
		map_generator.world_seed = randi()
		seed_edit.text = str(map_generator.world_seed)
	map_generator.generate()
	_update_player_preview()
	_focus_map()

func _on_random_pressed() -> void:
	map_generator.regenerate()
	seed_edit.text = str(map_generator.world_seed)
	_update_player_preview()
	_focus_map()

func _on_fit_pressed() -> void:
	_focus_map()

func _focus_map() -> void:
	var rect := Rect2(Vector2.ZERO, Vector2(map_generator.world_width * map_generator.tile_size, map_generator.world_height * map_generator.tile_size))
	camera.focus_rect(rect, get_viewport_rect().size)

func _on_generation_started() -> void:
	status_label.text = "Генерация карты..."

func _on_generation_done() -> void:
	status_label.text = "Готово: %dx%d, seed %d, объектов %d" % [map_generator.world_width, map_generator.world_height, map_generator.world_seed, map_generator.items_root.get_child_count()]

func _on_generation_error(message: String) -> void:
	status_label.text = "Ошибка: " + message
