extends Node
class_name ItemDB
## Единый каталог предметов для крафта/инвентаря/мира

const DB := {
	"wood": {"name": "Древесина", "stack": 999, "type": "resource"},
	"stone": {"name": "Камень", "stack": 999, "type": "resource"},
	"iron": {"name": "Железо", "stack": 999, "type": "ore"},
	"silver": {"name": "Серебро", "stack": 99, "type": "ore"},
	"mythril": {"name": "Мифрил", "stack": 99, "type": "ore"},
	"moonstone": {"name": "Лунный камень", "stack": 99, "type": "rare"},
	"herb": {"name": "Трава", "stack": 99, "type": "food"},
	"berry": {"name": "Ягоды", "stack": 99, "type": "food"},
	"mushroom": {"name": "Гриб", "stack": 99, "type": "food"},
	"crystal": {"name": "Кристалл", "stack": 50, "type": "rare"},
	"chest_common": {"name": "Сундук", "stack": 1, "type": "container"},
	"chest_rare": {"name": "Редкий сундук", "stack": 1, "type": "container"},
	"food_fruit": {"name": "Фрукт", "stack": 30, "type": "food"},
	"food_meal": {"name": "Жаркое", "stack": 20, "type": "food"},
	"potion_hp": {"name": "Зелье HP", "stack": 20, "type": "consumable"},
	"wooden_sword": {"name": "Деревянный меч", "stack": 1, "type": "weapon"},
	"pickaxe_stone": {"name": "Каменная кирка", "stack": 1, "type": "tool"},
	"torch": {"name": "Факел", "stack": 50, "type": "placeable"},
}

static func get_item(id: String) -> Dictionary:
	return DB.get(id, {})

static func get_item_name(id: String) -> String:
	return str(DB.get(id, {}).get("name", id))

static func get_stack(id: String) -> int:
	return int(DB.get(id, {}).get("stack", 99))
