extends Camera2D

@export var zoom_step := 0.1
@export var min_zoom := 0.35
@export var max_zoom := 3.0
@export var pan_speed := 1.0

var dragging := false
var last_mouse := Vector2.ZERO

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_MIDDLE:
			dragging = event.pressed
			last_mouse = event.position
			get_viewport().set_input_as_handled()
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_set_zoom(zoom.x + zoom_step)
			get_viewport().set_input_as_handled()
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_set_zoom(zoom.x - zoom_step)
			get_viewport().set_input_as_handled()
	elif event is InputEventMouseMotion and dragging:
		position -= event.relative * zoom.x * pan_speed
		get_viewport().set_input_as_handled()

func _set_zoom(value: float) -> void:
	var z := clampf(value, min_zoom, max_zoom)
	zoom = Vector2(z, z)

func focus_rect(rect: Rect2, viewport_size: Vector2) -> void:
	position = rect.get_center()
	var fit_x := viewport_size.x / maxf(rect.size.x, 1.0)
	var fit_y := viewport_size.y / maxf(rect.size.y, 1.0)
	var z := clampf(minf(fit_x, fit_y) * 0.92, min_zoom, max_zoom)
	zoom = Vector2(z, z)
