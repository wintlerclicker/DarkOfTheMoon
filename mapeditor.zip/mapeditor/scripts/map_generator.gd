extends Node2D
class_name MapGenerator
## Large, hand-balanced procedural fantasy world built from the supplied pixel-art packs.
## Godot 4.7+

@export_range(64, 512, 1) var world_width: int = 512
@export_range(64, 512, 1) var world_height: int = 512
@export var world_seed: int = 0
@export_range(16, 16, 1) var tile_size: int = 16

@export_group("Noise")
@export_range(0.001, 0.2, 0.001) var height_freq: float = 0.014
@export_range(0.001, 0.2, 0.001) var biome_freq: float = 0.010
@export_range(0.001, 0.5, 0.001) var detail_freq: float = 0.055

@export_group("World Balance")
@export_range(0, 2000, 1) var chest_count: int = 42
@export_range(2, 10, 1) var tree_min_spacing: int = 5
@export_range(3, 20, 1) var start_safe_radius: int = 14
@export_range(0.05, 0.45, 0.01) var max_water_ratio: float = 0.18
@export_range(0.05, 0.30, 0.01) var max_mountain_ratio: float = 0.18
@export_range(0.0, 1.0, 0.01) var forest_density: float = 0.16

@export_group("Landmarks")
@export_range(1, 8, 1) var village_count: int = 4
@export_range(1, 8, 1) var scenic_spot_count: int = 6
@export_range(20, 100, 1) var lake_radius: int = 62

@export_group("Assets")
@export_file("*.png") var grass_texture_path: String = "res://assets/tiles/TX Tileset Grass.png"
@export_file("*.png") var stone_ground_texture_path: String = "res://assets/tiles/TX Tileset Stone Ground.png"
@export_file("*.png") var plant_texture_path: String = "res://assets/plants/TX Plant.png"
@export_file("*.png") var woods_texture_path: String = "res://assets/woods/free_pixel_16_woods.png"
@export_file("*.png") var village_texture_path: String = "res://assets/village/Pixel 16 v2 village free.png"
@export_file("*.png") var props_texture_path: String = "res://assets/props/TX Props.png"

const WOODS_TREE_REGIONS := [
	Rect2(23, 24, 66, 65),
	Rect2(151, 23, 66, 66),
	Rect2(275, 10, 59, 70)
]
const TREE_REGIONS := [Rect2(24, 14, 113, 139), Rect2(161, 17, 95, 136), Rect2(295, 31, 79, 120)]
const BUSH_REGIONS := [Rect2(38, 198, 22, 19), Rect2(98, 195, 27, 25), Rect2(156, 190, 38, 32), Rect2(216, 185, 47, 42), Rect2(282, 186, 39, 45), Rect2(346, 190, 40, 35)]
const ROCK_REGION := Rect2(0, 430, 64, 50)
const CHEST_REGION := Rect2(96, 0, 32, 32)
const GRASS_TILES := [Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(3, 0), Vector2i(4, 0), Vector2i(5, 0)]
const STONE_TILE := Vector2i(8, 8)
const WATER_SOURCE_ID := 2
const LAYER_NAMES := ["Plains", "Forest", "Desert", "Snow", "Swamp", "Mountain", "Water"]
const LAYER_MODULATE := [
	Color(1.0, 1.0, 1.0), Color(0.94, 1.0, 0.90), Color(1.08, 0.91, 0.70),
	Color(0.90, 0.96, 1.08), Color(0.82, 0.94, 0.86), Color(0.88, 0.88, 0.84), Color(0.55, 0.75, 0.95)
]

enum Biome { PLAINS, FOREST, DESERT, SNOW, SWAMP, MOUNTAIN, WATER }

var tile_set: TileSet
var terrain_layers: Array[TileMapLayer] = []
var tile_layer: TileMapLayer
var decor: Node2D
var items_root: Node2D
var roads_root: Node2D
var poi_root: Node2D
var noise_h: FastNoiseLite
var noise_b: FastNoiseLite
var noise_d: FastNoiseLite
var noise_ore: FastNoiseLite
var biome_map: PackedInt32Array
var forest_core: PackedByteArray
var occupied_cells: Dictionary = {}
var tree_cells: Array[Vector2i] = []
var item_serial: int = 0
var _is_generating := false
var village_cells: Array[Vector2i] = []
var scenic_cells: Array[Vector2i] = []

signal generation_started
signal generation_done
signal item_picked(item_id: String, amount: int)
signal generation_error(message: String)

func _ready() -> void:
	_build()
	if world_seed == 0:
		world_seed = randi()

func _build() -> void:
	if is_instance_valid(tile_layer):
		return
	tile_set = _make_tileset()
	for i in range(LAYER_NAMES.size()):
		var layer := TileMapLayer.new()
		layer.name = LAYER_NAMES[i]
		layer.tile_set = tile_set
		layer.modulate = LAYER_MODULATE[i]
		layer.z_index = i
		add_child(layer)
		terrain_layers.append(layer)
	tile_layer = terrain_layers[Biome.PLAINS]

	roads_root = Node2D.new()
	roads_root.name = "RoadsAndPaths"
	roads_root.z_index = 50
	add_child(roads_root)
	decor = Node2D.new()
	decor.name = "Decor"
	add_child(decor)
	items_root = Node2D.new()
	items_root.name = "WorldItems"
	add_child(items_root)
	poi_root = Node2D.new()
	poi_root.name = "PointsOfInterest"
	poi_root.z_index = 120
	add_child(poi_root)

func _make_tileset() -> TileSet:
	var ts := TileSet.new()
	ts.tile_size = Vector2i(tile_size, tile_size)
	var grass := load(grass_texture_path) as Texture2D
	if grass != null:
		var src := TileSetAtlasSource.new()
		src.texture = grass
		src.texture_region_size = Vector2i(tile_size, tile_size)
		for y in range(int(grass.get_height() / tile_size)):
			for x in range(int(grass.get_width() / tile_size)):
				src.create_tile(Vector2i(x, y))
		ts.add_source(src, 0)
	var stone := load(stone_ground_texture_path) as Texture2D
	if stone != null:
		var src2 := TileSetAtlasSource.new()
		src2.texture = stone
		src2.texture_region_size = Vector2i(tile_size, tile_size)
		for y in range(int(stone.get_height() / tile_size)):
			for x in range(int(stone.get_width() / tile_size)):
				src2.create_tile(Vector2i(x, y))
		ts.add_source(src2, 1)
	var image := Image.create(tile_size, tile_size, false, Image.FORMAT_RGBA8)
	image.fill(Color("#4d82a4"))
	var water_texture := ImageTexture.create_from_image(image)
	var water_src := TileSetAtlasSource.new()
	water_src.texture = water_texture
	water_src.texture_region_size = Vector2i(tile_size, tile_size)
	water_src.create_tile(Vector2i.ZERO)
	ts.add_source(water_src, WATER_SOURCE_ID)
	return ts

func _validate_settings() -> bool:
	if world_width < 64 or world_height < 64:
		generation_error.emit("Для большого мира размер должен быть не меньше 64x64")
		return false
	if world_width > 512 or world_height > 512:
		generation_error.emit("Максимальный размер карты — 512x512")
		return false
	return true

func generate() -> void:
	if _is_generating or not _validate_settings():
		return
	_is_generating = true
	generation_started.emit()
	_init_noise()
	_fill_biomes()
	_build_forest_cores()
	_clear_objects()
	_paint_tiles()
	_build_world_paths()
	_place_plants()
	_place_villages()
	_place_scenic_spots()
	_place_props()
	_place_items()
	_is_generating = false
	generation_done.emit()

func regenerate(new_seed: int = 0) -> void:
	world_seed = new_seed if new_seed != 0 else randi()
	generate()

func _clear_objects() -> void:
	occupied_cells.clear()
	tree_cells.clear()
	village_cells.clear()
	scenic_cells.clear()
	item_serial = 0
	for c in roads_root.get_children(): c.free()
	for c in decor.get_children(): c.free()
	for c in items_root.get_children(): c.free()
	for c in poi_root.get_children(): c.free()

func _init_noise() -> void:
	noise_h = FastNoiseLite.new()
	noise_h.seed = world_seed
	noise_h.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise_h.frequency = height_freq
	noise_h.fractal_octaves = 5
	noise_b = FastNoiseLite.new()
	noise_b.seed = world_seed + 17
	noise_b.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise_b.frequency = biome_freq
	noise_b.fractal_octaves = 4
	noise_d = FastNoiseLite.new()
	noise_d.seed = world_seed + 33
	noise_d.noise_type = FastNoiseLite.TYPE_SIMPLEX
	noise_d.frequency = detail_freq
	noise_ore = FastNoiseLite.new()
	noise_ore.seed = world_seed + 55
	noise_ore.noise_type = FastNoiseLite.TYPE_CELLULAR
	noise_ore.frequency = 0.06
	noise_ore.cellular_return_type = FastNoiseLite.RETURN_DISTANCE

func _fill_biomes() -> void:
	var n := world_width * world_height
	biome_map = PackedInt32Array()
	biome_map.resize(n)
	var cx := world_width * 0.5
	var cy := world_height * 0.5
	for y in range(world_height):
		for x in range(world_width):
			var elev := noise_h.get_noise_2d(float(x), float(y))
			var bio := noise_b.get_noise_2d(float(x), float(y))
			var b := Biome.PLAINS
			if elev > 0.50:
				b = Biome.MOUNTAIN
			elif bio < -0.46:
				b = Biome.DESERT
			elif bio < -0.08:
				b = Biome.PLAINS
			elif bio < 0.30:
				b = Biome.FOREST
			elif bio < 0.44:
				b = Biome.SWAMP
			else:
				b = Biome.SNOW
			biome_map[y * world_width + x] = b

	# Large lake: scenic focal point, but kept away from the starting heartland.
	var lake_center := Vector2(world_width * 0.68, world_height * 0.30)
	var lake_r := float(lake_radius)
	for y in range(world_height):
		for x in range(world_width):
			var p := Vector2(x, y)
			var dx := (p.x - lake_center.x) / lake_r
			var dy := (p.y - lake_center.y) / (lake_r * 0.72)
			var irregular := noise_d.get_noise_2d(float(x) * 0.35, float(y) * 0.35) * 0.18
			if dx * dx + dy * dy < 1.0 + irregular:
				biome_map[y * world_width + x] = Biome.WATER

	# A broad river connects the lake to the south-west, giving the world a natural travel axis.
	for y in range(int(world_height * 0.25), world_height - 8):
		var t := float(y) / float(world_height)
		var center_x := int(world_width * 0.70 - t * world_width * 0.42 + sin(t * 9.0) * 18.0)
		var width := 4 + int(2.0 * abs(sin(t * 6.0)))
		for ox in range(-width, width + 1):
			var x := center_x + ox
			if x >= 0 and x < world_width:
				biome_map[y * world_width + x] = Biome.WATER

	# Strong macro-forest pockets for readable exploration zones.
	var forests := [
		Vector2(world_width * 0.20, world_height * 0.20),
		Vector2(world_width * 0.86, world_height * 0.18),
		Vector2(world_width * 0.22, world_height * 0.76),
		Vector2(world_width * 0.78, world_height * 0.78)
	]
	for center in forests:
		for y in range(maxi(0, int(center.y) - 68), mini(world_height, int(center.y) + 69)):
			for x in range(maxi(0, int(center.x) - 68), mini(world_width, int(center.x) + 69)):
				var p := Vector2(x, y)
				var d := p.distance_to(center)
				if d < 68.0 and biome_map[y * world_width + x] != Biome.WATER:
					var chance := clampf(1.0 - d / 72.0, 0.0, 1.0)
					if noise_d.get_noise_2d(float(x), float(y)) > -0.35 + chance * 0.18:
						biome_map[y * world_width + x] = Biome.FOREST

	# Mountain crown in the north-east; this creates a destination and a natural barrier.
	var ridge_center := Vector2(world_width * 0.80, world_height * 0.67)
	for y in range(world_height):
		for x in range(world_width):
			var p := Vector2(x, y)
			var ridge: float = absf((p.x - ridge_center.x) * 0.55 - (p.y - ridge_center.y))
			if ridge < 13.0 and p.x > world_width * 0.58 and p.y > world_height * 0.45:
				if biome_map[y * world_width + x] != Biome.WATER:
					biome_map[y * world_width + x] = Biome.MOUNTAIN

	# Protected central heartland and village-friendly plains.
	var safe_center := Vector2(cx, cy)
	for y in range(world_height):
		for x in range(world_width):
			if Vector2(x, y).distance_to(safe_center) <= start_safe_radius:
				biome_map[y * world_width + x] = Biome.PLAINS

	_smooth_water()
	_balance_world()

func _balance_world() -> void:
	var water_count := 0
	var mountain_count := 0
	var total := float(world_width * world_height)
	for b in biome_map:
		if b == Biome.WATER: water_count += 1
		elif b == Biome.MOUNTAIN: mountain_count += 1
	if water_count / total > max_water_ratio:
		for y in range(world_height):
			for x in range(world_width):
				var i := y * world_width + x
				if biome_map[i] == Biome.WATER and noise_b.get_noise_2d(float(x), float(y)) > -0.05:
					biome_map[i] = Biome.PLAINS
	if mountain_count / total > max_mountain_ratio:
		for y in range(world_height):
			for x in range(world_width):
				var i := y * world_width + x
				if biome_map[i] == Biome.MOUNTAIN and noise_h.get_noise_2d(float(x), float(y)) < 0.66:
					biome_map[i] = Biome.FOREST if noise_b.get_noise_2d(float(x), float(y)) > 0.0 else Biome.PLAINS

func _smooth_water() -> void:
	var copy := biome_map.duplicate()
	for y in range(1, world_height - 1):
		for x in range(1, world_width - 1):
			var i := y * world_width + x
			if copy[i] != Biome.WATER: continue
			var land := 0
			for oy in range(-1, 2):
				for ox in range(-1, 2):
					if copy[(y + oy) * world_width + (x + ox)] != Biome.WATER: land += 1
			if land >= 7: biome_map[i] = Biome.PLAINS

func _build_forest_cores() -> void:
	forest_core = PackedByteArray()
	forest_core.resize(world_width * world_height)
	for y in range(2, world_height - 2):
		for x in range(2, world_width - 2):
			var i := y * world_width + x
			if biome_map[i] != Biome.FOREST: continue
			var forest_n := 0
			for oy in range(-2, 3):
				for ox in range(-2, 3):
					if biome_map[(y + oy) * world_width + (x + ox)] == Biome.FOREST: forest_n += 1
			forest_core[i] = 1 if forest_n >= 17 else 0

func _grass_tile(x: int, y: int) -> Vector2i:
	return GRASS_TILES[absi(x * 3 + y * 7 + world_seed) % GRASS_TILES.size()]

func _paint_tiles() -> void:
	for layer in terrain_layers: layer.clear()
	for y in range(world_height):
		for x in range(world_width):
			var b: int = biome_map[y * world_width + x]
			if b == Biome.WATER:
				terrain_layers[Biome.WATER].set_cell(Vector2i(x, y), WATER_SOURCE_ID, Vector2i.ZERO)
			elif b == Biome.MOUNTAIN:
				terrain_layers[Biome.MOUNTAIN].set_cell(Vector2i(x, y), 1, STONE_TILE)
			else:
				terrain_layers[b].set_cell(Vector2i(x, y), 0, _grass_tile(x, y))

func _build_world_paths() -> void:
	var center := Vector2(world_width * 0.50, world_height * 0.50)
	var lake := Vector2(world_width * 0.68, world_height * 0.30)
	_draw_path(center, lake, 5.0)
	var villages := [
		Vector2(world_width * 0.28, world_height * 0.32),
		Vector2(world_width * 0.50, world_height * 0.68),
		Vector2(world_width * 0.80, world_height * 0.48),
		Vector2(world_width * 0.32, world_height * 0.84)
	]
	for v in villages:
		_draw_path(center, v, 4.0)
	_draw_path(villages[0], lake, 3.0)
	_draw_path(villages[2], Vector2(world_width * 0.80, world_height * 0.67), 3.0)

func _draw_path(a: Vector2, b: Vector2, width: float) -> void:
	var line := Line2D.new()
	line.width = width
	line.default_color = Color(0.42, 0.29, 0.18, 0.72)
	line.joint_mode = Line2D.LINE_JOINT_ROUND
	line.begin_cap_mode = Line2D.LINE_CAP_ROUND
	line.end_cap_mode = Line2D.LINE_CAP_ROUND
	var pts := PackedVector2Array()
	var segments := 28
	for i in range(segments + 1):
		var t := float(i) / float(segments)
		var p := a.lerp(b, t)
		p.x += sin(t * 5.4 + world_seed * 0.001) * 8.0
		p.y += cos(t * 4.7 + world_seed * 0.001) * 6.0
		pts.append(p * tile_size + Vector2(tile_size * 0.5, tile_size * 0.5))
	line.points = pts
	roads_root.add_child(line)

func _place_plants() -> void:
	var tex := load(plant_texture_path) as Texture2D
	var woods_tex := load(woods_texture_path) as Texture2D
	if tex == null: return
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + 99
	for y in range(5, world_height - 5):
		for x in range(5, world_width - 5):
			var i := y * world_width + x
			var b: int = biome_map[i]
			if b in [Biome.WATER, Biome.MOUNTAIN, Biome.DESERT]: continue
			var chance := 0.0
			var prefer_tree := false
			if b == Biome.FOREST:
				chance = forest_density if forest_core[i] == 1 else 0.035
				prefer_tree = forest_core[i] == 1 or rng.randf() < 0.22
			elif b == Biome.PLAINS: chance = 0.0025
			elif b == Biome.SWAMP: chance = 0.014
			elif b == Biome.SNOW: chance = 0.006
			if rng.randf() > chance: continue
			var cell := Vector2i(x, y)
			if _cell_occupied_near(cell, 2): continue
			if prefer_tree and _tree_too_close(cell, tree_min_spacing): continue
			occupied_cells[cell] = true
			if prefer_tree:
				tree_cells.append(cell)
			if woods_tex != null and prefer_tree:
				_add_plant(woods_tex, WOODS_TREE_REGIONS[rng.randi() % WOODS_TREE_REGIONS.size()], x, y, rng, rng.randf_range(0.82, 1.02), 1)
			else:
				_add_plant(tex, BUSH_REGIONS[rng.randi() % BUSH_REGIONS.size()], x, y, rng, rng.randf_range(0.85, 1.05))

func _tree_too_close(cell: Vector2i, spacing: int) -> bool:
	for tree_cell in tree_cells:
		if float(cell.distance_squared_to(tree_cell)) < float(spacing * spacing): return true
	return false

func _place_villages() -> void:
	var tex := load(village_texture_path) as Texture2D
	if tex == null: return
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + 404
	var candidates := [
		Vector2i(int(world_width * 0.28), int(world_height * 0.32)),
		Vector2i(int(world_width * 0.50), int(world_height * 0.68)),
		Vector2i(int(world_width * 0.80), int(world_height * 0.48)),
		Vector2i(int(world_width * 0.32), int(world_height * 0.84))
	]
	for base in candidates:
		if village_cells.size() >= village_count: break
		var cell := _find_nearest_plains(base, 26)
		if cell == Vector2i(-1, -1): continue
		if Vector2(cell.x - world_width * 0.5, cell.y - world_height * 0.5).length() < start_safe_radius + 20: continue
		if _village_too_close(cell, 48) or _cell_occupied_near(cell, 7): continue
		village_cells.append(cell)
		occupied_cells[cell] = true
		var house_region := Rect2(68, 123, 72, 101) if rng.randf() < 0.5 else Rect2(148, 155, 115, 69)
		_add_village(tex, house_region, cell.x, cell.y, rng)

func _find_nearest_plains(base: Vector2i, radius: int) -> Vector2i:
	var best := Vector2i(-1, -1)
	var best_d := 1.0e20
	for y in range(maxi(4, base.y - radius), mini(world_height - 4, base.y + radius + 1)):
		for x in range(maxi(4, base.x - radius), mini(world_width - 4, base.x + radius + 1)):
			if biome_map[y * world_width + x] != Biome.PLAINS: continue
			var d := base.distance_squared_to(Vector2i(x, y))
			if d < best_d and not _cell_occupied_near(Vector2i(x, y), 5):
				best_d = d
				best = Vector2i(x, y)
	return best

func _village_too_close(cell: Vector2i, spacing: int) -> bool:
	for other in village_cells:
		if cell.distance_to(other) < float(spacing): return true
	return false

func _add_village(tex: Texture2D, region: Rect2, x: int, y: int, rng: RandomNumberGenerator) -> void:
	var clearing := Polygon2D.new()
	clearing.polygon = PackedVector2Array([Vector2(-54, 8), Vector2(-24, -24), Vector2(28, -24), Vector2(58, 6), Vector2(42, 38), Vector2(-42, 38)])
	clearing.position = Vector2(x * tile_size + 8, y * tile_size + 8)
	clearing.color = Color(0.75, 0.58, 0.34, 0.30)
	clearing.z_index = int(clearing.position.y) - 2
	decor.add_child(clearing)
	for offset in [Vector2(-28, 0), Vector2(0, -12), Vector2(28, 4)]:
		var s := Sprite2D.new()
		s.texture = tex
		s.region_enabled = true
		s.region_rect = region
		s.centered = true
		s.position = Vector2(x * tile_size + 8, y * tile_size + 8) + offset
		s.scale = Vector2(0.42, 0.42)
		s.z_index = int(s.position.y) + 20
		decor.add_child(s)

func _place_scenic_spots() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + 909
	var candidates := [
		Vector2i(int(world_width * 0.60), int(world_height * 0.24)),
		Vector2i(int(world_width * 0.84), int(world_height * 0.68)),
		Vector2i(int(world_width * 0.13), int(world_height * 0.48)),
		Vector2i(int(world_width * 0.56), int(world_height * 0.82)),
		Vector2i(int(world_width * 0.34), int(world_height * 0.16)),
		Vector2i(int(world_width * 0.44), int(world_height * 0.48))
	]
	for base in candidates:
		if scenic_cells.size() >= scenic_spot_count: break
		var cell := _find_nearest_plains(base, 20)
		if cell == Vector2i(-1, -1) or _cell_occupied_near(cell, 4): continue
		scenic_cells.append(cell)
		occupied_cells[cell] = true
		_add_scenic_marker(cell, rng)

func _add_scenic_marker(cell: Vector2i, rng: RandomNumberGenerator) -> void:
	var glow := Polygon2D.new()
	glow.polygon = PackedVector2Array([Vector2(-18, 0), Vector2(-9, -14), Vector2(9, -14), Vector2(18, 0), Vector2(9, 14), Vector2(-9, 14)])
	glow.position = Vector2(cell.x * tile_size + 8, cell.y * tile_size + 8)
	glow.color = Color(0.95, 0.82, 0.45, 0.22)
	glow.z_index = int(glow.position.y) + 2
	poi_root.add_child(glow)
	# Small ring of flowers/bushes creates a readable landmark without adding UI clutter.
	var tex := load(plant_texture_path) as Texture2D
	if tex == null: return
	for i in range(6):
		var a := TAU * float(i) / 6.0
		var px := int(round(cell.x + cos(a) * 2.5))
		var py := int(round(cell.y + sin(a) * 2.5))
		_add_plant(tex, BUSH_REGIONS[i % BUSH_REGIONS.size()], px, py, rng, 0.72)

func _place_props() -> void:
	var tex := load(props_texture_path) as Texture2D
	if tex == null: return
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + 701
	for y in range(4, world_height - 4, 3):
		for x in range(4, world_width - 4, 3):
			var b: int = biome_map[y * world_width + x]
			if b in [Biome.WATER, Biome.MOUNTAIN, Biome.DESERT]: continue
			if rng.randf() > 0.006 or _cell_occupied_near(Vector2i(x, y), 2): continue
			occupied_cells[Vector2i(x, y)] = true
			_add_prop(tex, ROCK_REGION, x, y, rng)

func _cell_occupied_near(cell: Vector2i, radius: int) -> bool:
	for oy in range(-radius, radius + 1):
		for ox in range(-radius, radius + 1):
			if occupied_cells.has(cell + Vector2i(ox, oy)): return true
	return false

func _add_plant(tex: Texture2D, region: Rect2, x: int, y: int, rng: RandomNumberGenerator, sc: float, atlas_kind: int = 0) -> void:
	var s := Sprite2D.new()
	s.texture = tex
	s.region_enabled = true
	s.region_rect = region
	s.centered = true
	s.position = Vector2(x * tile_size + 8 + rng.randf_range(-2, 2), y * tile_size + 8 + rng.randf_range(-1, 1))
	s.offset = Vector2(0, -region.size.y * (0.22 if atlas_kind == 1 else 0.12))
	s.z_index = int(s.position.y)
	s.scale = Vector2(sc, sc)
	s.flip_h = rng.randf() < 0.5
	decor.add_child(s)

func _add_prop(tex: Texture2D, region: Rect2, x: int, y: int, rng: RandomNumberGenerator) -> void:
	var s := Sprite2D.new()
	s.texture = tex
	s.region_enabled = true
	s.region_rect = region
	s.centered = true
	s.position = Vector2(x * tile_size + 8, y * tile_size + 8)
	s.scale = Vector2(0.45, 0.45)
	s.z_index = int(s.position.y)
	s.rotation = rng.randf_range(-0.12, 0.12)
	decor.add_child(s)

func _place_items() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + 200
	for y in range(3, world_height - 3):
		for x in range(3, world_width - 3):
			var b: int = biome_map[y * world_width + x]
			var ore_n := noise_ore.get_noise_2d(float(x), float(y))
			if b == Biome.MOUNTAIN:
				if ore_n < -0.75 and rng.randf() < 0.012: _spawn_item("mythril", x, y, 1)
				elif ore_n < -0.65 and rng.randf() < 0.03: _spawn_item("silver", x, y, 1)
				elif ore_n < -0.55 and rng.randf() < 0.10: _spawn_item("iron", x, y, 1 + rng.randi_range(0, 2))
				elif ore_n < -0.35 and rng.randf() < 0.05: _spawn_item("stone", x, y, 2 + rng.randi_range(0, 3))
			if b in [Biome.PLAINS, Biome.FOREST] and ore_n < -0.7 and rng.randf() < 0.008: _spawn_item("moonstone", x, y, 1)
			if b == Biome.SNOW and ore_n < -0.82 and rng.randf() < 0.008: _spawn_item("crystal", x, y, 1)
	for y in range(4, world_height - 4, 3):
		for x in range(4, world_width - 4, 3):
			var b: int = biome_map[y * world_width + x]
			if b == Biome.FOREST and forest_core[y * world_width + x] == 1 and rng.randf() < 0.025: _spawn_item("wood", x, y, 1 + rng.randi_range(0, 2))
			if b == Biome.FOREST and rng.randf() < 0.012: _spawn_item("mushroom", x, y, 1)
			if b == Biome.PLAINS and rng.randf() < 0.010: _spawn_item("herb", x, y, 1)
			if b in [Biome.FOREST, Biome.PLAINS] and rng.randf() < 0.007: _spawn_item("berry", x, y, 1 + rng.randi_range(0, 1))
			if b == Biome.SWAMP and rng.randf() < 0.018: _spawn_item("mushroom", x, y, 1)
	var chests := 0
	var tries := 0
	while chests < chest_count and tries < chest_count * 50:
		tries += 1
		var x := rng.randi_range(6, world_width - 7)
		var y := rng.randi_range(6, world_height - 7)
		var cell := Vector2i(x, y)
		var b: int = biome_map[y * world_width + x]
		if b == Biome.WATER or _cell_occupied_near(cell, 4): continue
		var id := "chest_rare" if b == Biome.MOUNTAIN and rng.randf() < 0.5 else "chest_common"
		if _spawn_item(id, x, y, 1): chests += 1

func _spawn_item(id: String, tx: int, ty: int, amount: int) -> bool:
	var meta := ItemDB.get_item(id)
	if meta.is_empty(): return false
	var cell := Vector2i(tx, ty)
	if _cell_occupied_near(cell, 1): return false
	occupied_cells[cell] = true
	item_serial += 1
	var node := Area2D.new()
	node.name = "Item_%s_%d" % [id, item_serial]
	node.position = Vector2(tx * tile_size + 8, ty * tile_size + 8)
	node.z_index = int(node.position.y)
	node.set_meta("item_id", id)
	node.set_meta("amount", amount)
	node.set_meta("instance_id", item_serial)
	var cs := CollisionShape2D.new()
	var sh := CircleShape2D.new()
	sh.radius = 7
	cs.shape = sh
	node.add_child(cs)
	var props_tex := load(props_texture_path) as Texture2D
	if props_tex != null and id.begins_with("chest"):
		var sprite := Sprite2D.new()
		sprite.texture = props_tex
		sprite.region_enabled = true
		sprite.region_rect = CHEST_REGION
		sprite.scale = Vector2(0.5, 0.5)
		sprite.modulate = Color(1.0, 0.85, 0.55) if id == "chest_rare" else Color.WHITE
		node.add_child(sprite)
	else:
		var vis := ColorRect.new()
		vis.size = Vector2(8, 8)
		vis.position = Vector2(-4, -4)
		vis.color = _item_color(id)
		node.add_child(vis)
	node.body_entered.connect(func(body: Node):
		if not (body.is_in_group("player") or body.is_in_group("player_character")): return
		var inv = body.get_node_or_null("Inventory")
		if inv == null or not inv.has_method("add_item"): return
		var result = inv.add_item(id, amount)
		if result == null or bool(result):
			item_picked.emit(id, amount)
			node.queue_free()
	)
	node.monitoring = true
	node.monitorable = false
	items_root.add_child(node)
	return true

func _item_color(id: String) -> Color:
	var colors := {"wood": Color(0.55, 0.35, 0.15), "stone": Color(0.55, 0.55, 0.58), "iron": Color(0.7, 0.45, 0.35), "silver": Color(0.8, 0.85, 0.9), "mythril": Color(0.4, 0.75, 0.85), "moonstone": Color(0.7, 0.75, 1.0), "herb": Color(0.3, 0.7, 0.35), "berry": Color(0.85, 0.25, 0.35), "mushroom": Color(0.75, 0.55, 0.4), "crystal": Color(0.55, 0.35, 0.85)}
	return colors.get(id, Color.WHITE)

func get_biome_at_world(pos: Vector2) -> int:
	if biome_map.is_empty(): return Biome.PLAINS
	var x := clampi(int(pos.x / tile_size), 0, world_width - 1)
	var y := clampi(int(pos.y / tile_size), 0, world_height - 1)
	return biome_map[y * world_width + x]

func biome_name(b: int) -> String:
	match b:
		Biome.PLAINS: return "Равнины"
		Biome.FOREST: return "Лес"
		Biome.DESERT: return "Пустыня"
		Biome.SNOW: return "Снег"
		Biome.SWAMP: return "Болото"
		Biome.MOUNTAIN: return "Горы"
		Biome.WATER: return "Озеро / река"
		_: return "?"

func get_all_item_ids() -> Array:
	return ItemDB.DB.keys()
